#include "kernel_operator.h"

using namespace AscendC;

// Queue synchronization covers MTE2 -> vector -> MTE3. The explicit vector
// barriers also make each dependent arithmetic stage unambiguous.
template <typename T>
class KernelSigmoidCustom {
public:
    __aicore__ inline KernelSigmoidCustom() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y,
                               uint64_t totalLength, uint32_t tileLength)
    {
        totalLength_ = totalLength;
        tileLength_ = tileLength;
        xGm_.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(x), totalLength_);
        yGm_.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(y), totalLength_);
        pipe_.InitBuffer(inputQueue_, 1, tileLength_ * sizeof(T));
        pipe_.InitBuffer(outputQueue_, 1, tileLength_ * sizeof(T));
        pipe_.InitBuffer(floatBuffer_, tileLength_ * sizeof(float));
        pipe_.InitBuffer(onesBuffer_, tileLength_ * sizeof(float));
        pipe_.InitBuffer(resultBuffer_, tileLength_ * sizeof(float));
    }

    __aicore__ inline void Process()
    {
        const uint64_t tileCount = (totalLength_ + tileLength_ - 1) / tileLength_;
        for (uint64_t tile = GetBlockIdx(); tile < tileCount; tile += GetBlockNum()) {
            const uint64_t offset = tile * tileLength_;
            const uint64_t remaining = totalLength_ - offset;
            const uint32_t count = remaining < tileLength_
                ? static_cast<uint32_t>(remaining) : tileLength_;
            CopyIn(offset, count);
            Compute(count);
            CopyOut(offset, count);
        }
    }

private:
    __aicore__ inline void CopyIn(uint64_t offset, uint32_t count)
    {
        LocalTensor<T> input = inputQueue_.AllocTensor<T>();
        const DataCopyExtParams copyParams{1, count * static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
        const DataCopyPadExtParams<T> padParams{false, 0, 0, static_cast<T>(0)};
        DataCopyPad(input, xGm_[offset], copyParams, padParams);
        inputQueue_.EnQue(input);
    }

    __aicore__ inline void Compute(uint32_t count)
    {
        LocalTensor<T> input = inputQueue_.DeQue<T>();
        LocalTensor<T> output = outputQueue_.AllocTensor<T>();
        LocalTensor<float> tmp = floatBuffer_.Get<float>();
        LocalTensor<float> ones = onesBuffer_.Get<float>();
        LocalTensor<float> result = resultBuffer_.Get<float>();
        if constexpr (sizeof(T) == sizeof(half)) {
            Cast(tmp, input, RoundMode::CAST_NONE, count);
        } else {
            Muls(tmp, input, 1.0f, count);
        }
        PipeBarrier<PIPE_V>();
        Muls(tmp, tmp, -1.0f, count);
        PipeBarrier<PIPE_V>();
        Exp(tmp, tmp, count);
        PipeBarrier<PIPE_V>();
        Adds(tmp, tmp, 1.0f, count);
        Duplicate(ones, 1.0f, count);
        PipeBarrier<PIPE_V>();
        // Vector Reciprocal alone is approximate on 910B; Div meets the
        // float32 accuracy target without relaxing the verification tolerance.
        Div(result, ones, tmp, count);
        PipeBarrier<PIPE_V>();
        if constexpr (sizeof(T) == sizeof(half)) {
            Cast(output, result, RoundMode::CAST_RINT, count);
        } else {
            Muls(output, result, 1.0f, count);
        }
        outputQueue_.EnQue(output);
        inputQueue_.FreeTensor(input);
    }

    __aicore__ inline void CopyOut(uint64_t offset, uint32_t count)
    {
        LocalTensor<T> output = outputQueue_.DeQue<T>();
        const DataCopyExtParams copyParams{1, count * static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
        // Unlike plain DataCopy, the extended form writes exactly count elements
        // without rounding the final GM write up to 32 bytes.
        DataCopyPad(yGm_[offset], output, copyParams);
        outputQueue_.FreeTensor(output);
    }

    TPipe pipe_;
    TQue<QuePosition::VECIN, 1> inputQueue_;
    TQue<QuePosition::VECOUT, 1> outputQueue_;
    TBuf<QuePosition::VECCALC> floatBuffer_;
    TBuf<QuePosition::VECCALC> onesBuffer_;
    TBuf<QuePosition::VECCALC> resultBuffer_;
    GlobalTensor<T> xGm_;
    GlobalTensor<T> yGm_;
    uint64_t totalLength_;
    uint32_t tileLength_;
};

extern "C" __global__ __aicore__ void sigmoid_custom(
    GM_ADDR x, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling)
{
    GET_TILING_DATA(tilingData, tiling);
    KernelSigmoidCustom<DTYPE_X> kernel;
    kernel.Init(x, y, tilingData.totalLength, tilingData.tileLength);
    kernel.Process();
}
